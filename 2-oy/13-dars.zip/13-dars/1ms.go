1)https://leetcode.com/problems/palindrome-number/submissions/1193367213/
2)
3)